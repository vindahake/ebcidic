package Convert::IBM390;
$VERSION = '0.22';

#--- DUMMY ----------------------------------------------------------
#
# This is a dummy .pm file, needed only because CPAN expects one.
# To generate the real thing, run 'perl Makefile.PL'.
#
#--- DUMMY ----------------------------------------------------------

1;
__END__
